# Actor Empire Shared World Map

This archive contains the current shared interactive world-map source used throughout Actor Empire.

## Core files

- `views/lifestyle/business/components/InteractiveRegionMap.tsx` - reusable React/SVG map component.
- `views/lifestyle/business/components/worldMapGeometry.ts` - world topology projection and country geometry helpers.
- `services/regionMap.ts` - region definitions, country membership, normalization, and summaries.
- `vendor/world-atlas/countries-110m.json` - a copy of the geographic data consumed from the `world-atlas` package.

## Current reuse points

- Production House / Greenlight location selection
- Release Wizard theatrical-region selection
- Studio Finance build planning
- Cinema Commission Cut

## Runtime dependencies

- `react` `^19.2.3`
- `d3-geo` `^3.1.1`
- `topojson-client` `^3.1.0`
- `world-atlas` `^2.0.2`

The source files preserve their paths from the Actor Empire repository. `InteractiveRegionMap.tsx` also uses Actor Empire's `BoxOfficeRegionId` type, while `regionMap.ts` reads `BOX_OFFICE_REGIONS` from the existing cinema-chain service.

Packaged from the current Actor Empire working tree on 2026-09-14.
